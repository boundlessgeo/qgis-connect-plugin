# -*- coding: utf-8 -*-

def classFactory(iface):
    from connecttest.connecttest_plugin import ConnectTestPlugin
    return ConnectTestPlugin(iface)
